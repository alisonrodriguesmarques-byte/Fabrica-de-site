// seleção das tegs
const input = document.querySelector('#formulario input');
const criar = document.querySelector('#formulario button');
const tarefas = document.querySelector('.tarefas');
const lista = document.createElement('ul');

let atividades = [];

let proximoId = 1; 

// onde ás tarefas vão aparecer
lista.id = "lista-atividades";
tela.appendChild(lista);

// cria uma lista no js para as tarefas
function novaAtividade(atividade) {
    const modelo = document.createElement('li');
    modelo.classList.add('atividade');

    const tarefa = {
        id: proximoId++,
        completo: false,
        nome: atividade,
    };

    atividades.push(tarefa);

    const indice = atividades.length - 1;
    modelo.innerHTML = `<div class="card-atividade card-${atividades.length}">
    ${criarHTMLTarefa(tarefa, indice)}</div>`;
    lista.appendChild(modelo);

    atualizarContadores();

document.querySelector(".remover-btn").addEventListener('click', function () {
    const indice = this.dataset.index;
    atividades.splice(indice, 1);
    this.closest("li").remove();
    atualizarContadores();

})

}
// contagem das tarefas criadas e concluídas
function atualizarContadores() {
    const criadas = document.getElementById("criadas");
    const concluidas = document.getElementById("concluídas");

    criadas.innerText = ` ${atividades.length}`;
    const completas = atividades.filter(t => t.completo).length;
    concluidas.innerText = ` ${completas} de ${atividades.length}`;
    atualizarContadores();
}

criar.addEventListener('click', function () {
    const texto = input.value.trim();
    if (texto !== "") {
        novaAtividade(texto);
        input.value = "";
    }
});
// cria ás tarefas atraves do texto digitado
function criarHTMLTarefa(tarefa) {
    const li = document.createElement("li");
    li.innerHTML = `
        <input type="checkbox" ${tarefa.completo ? 'checked' : ''}
            data-id"${tarefa.id}" class="checkbox-tarefa">
        <span class="texto-tarefa ${tarefa.completo ? 'concluida' : ''}"> 
        ${tarefa.texto}</span>
        <button title="Deletar tarefa"
                class="botao-deletar"
                data-id="${tarefa.id}">
            <img src="/img/lixeira1.png">
        </button>
    `;
    return li;
    const checkbox = modelo.querySelector(`#tarefa-${indice}`);
    checkbox.addEventListener('change', function () {

        atividades[indice].completo = this.checked;
        atualizarContadores();
    });

}

function preencherLista(){
    area.innerHTML = "";
    atividades.forEach(atividades => {
    area.appendChild(criarHTMLTarefa(atividades))

    atualizarContadores();
    });
}