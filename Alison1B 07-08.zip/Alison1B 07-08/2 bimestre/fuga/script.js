const botao = document.getElementById(`botao`);

    function fuga(){
        const larguraTela = window.innerWidth;
        const alturaTela = window.innerHeight;

        const larguraBotao = botao.offsetWidth;
        const alturaBotao = botao.offsetHeight;

        const novaPosX = Math.random() * (larguraTela - larguraBotao);
        const novaPosy = Math.random() * (alturaTela - alturaBotao);

        botao.style.left = `${novaPosX}px`;
        botao.style.top = `${novaPosy}px`;

    }

    botao.addEventListener("mouseover" , () =>{
        fuga();  });