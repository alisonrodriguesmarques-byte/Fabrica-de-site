let nome = "Marcos";
let numero = 12;
let pet = 'gato';
alert ("🤖player: " + nome +" - 👾level: " + numero + " - 🐶animal: " + pet);