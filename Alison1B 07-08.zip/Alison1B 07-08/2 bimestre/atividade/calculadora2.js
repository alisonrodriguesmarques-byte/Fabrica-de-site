function somar(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    let somar = parseFloat(num1) + parseFloat(num2);

    document.getElementById('valo1').innerText =  somar;
   let resposta = (num1 >  num2) ? "o " + num1 + " é maior que o " + num2 :  "o " + num2 + " é menor que " + num1 ;
   alert(resposta)
}
function multiplicar(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    let multiplicar = parseFloat(num1) * parseFloat(num2);

    document.getElementById('valo2').innerText = multiplicar;
     let resposta = (num1 >  num2) ? "o " + num1 + " é maior que o " + num2 :  "o " + num1 + " é menor que " + num2 ;
   alert(resposta)
}
function dividir(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    let  dividir= parseFloat(num1) / parseFloat(num2);

    document.getElementById('valo3').innerText = dividir;
     let resposta = (num1 >  num2) ? "o " + num1 + " é maior que o " + num2 :  "o " + num1 + " é menor que " + num2 ;
   alert(resposta)
}
function subtrair(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    let  subtrair= parseFloat(num1) - parseFloat(num2);

    document.getElementById('valo4').innerText = subtrair;
    let resposta = (num1 >  num2) ? "o " + num1 + " é maior que o " + num2 :  "o " + num1 + " é menor que " + num2 ;
   alert(resposta)
}