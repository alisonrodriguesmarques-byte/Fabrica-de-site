 function img(){ 
    
    document.getElementById("img1").style.display = 'block'
}