function ola(){
  let nome2 = document.getElementById('nome2').value;
  document.getElementById('nome').innerText = 'seja bem vindo 😁👍  ' + nome2;

  document.getElementById('nome').style.animation = `none`
  void document.getElementById('nome').offsetWidth
  setTimeout(() =>{
      document.getElementById('nome').style.animation = `pulse .7s`
  }, 10)
}