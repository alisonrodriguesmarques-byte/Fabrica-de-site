let estudante = false;
let nome = "Marcos";
let idade = 13 ;
let mensagem = estudante ? 'sim' : 'não';

document.getElementById('mensagem').innerText = ( nome + ' é estudante?' + mensagem);
let notificaçao = "vc não esta no nosso app";
alert(notificaçao);
