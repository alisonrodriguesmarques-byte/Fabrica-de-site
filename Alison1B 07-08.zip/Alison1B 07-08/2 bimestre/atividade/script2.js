let nome = prompt ("Qual seu nome player👾");
alert ("olá:" + nome);
