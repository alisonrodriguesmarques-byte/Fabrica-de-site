let num = Number(prompt('soma de 9:'));
let soma =9;
alert( num + soma);
let nume = Number(prompt('multiplicação de 9:'));
let mult =9;
alert( nume * mult);
let numer = Number(prompt('subtração de 9:'));
let subtração =9;
alert( numer - subtração);

