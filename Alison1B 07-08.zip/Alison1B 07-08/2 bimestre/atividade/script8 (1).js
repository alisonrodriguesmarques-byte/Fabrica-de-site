function enviar(){
  let bc =  document.getElementById('nome').value;
   document.getElementById("palavra").innerText = bc + "   sua conta foi criada com sucesso✅";
   alert("conta criada");
}