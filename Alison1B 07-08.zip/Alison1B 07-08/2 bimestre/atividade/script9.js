function enviar(){
 const name = document.getElementById("nome").value;
 const age = document.getElementById("email").value;
  if(name === '' || age === ''){
    alert("Por favor, preencha os dados ");
  }
  else {
    document.getElementById("palavra").innerText = name + "   sua conta foi criada com sucesso✅";
  }
}
