function cor(){
    let cor = "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6,"0");
    let cor1 = "#" + Math.floor(Math.random() * 16887215).toString(16).padStart(6,"0");
    document.body.style.backgroundColor = cor;
    document.getElementById("botao").style.backgroundColor = cor1;
}