function somar(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    let somar = parseFloat(num1) + parseFloat(num2);

    alert (somar);
}
function multiplicar(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    let multiplicar = parseFloat(num1) * parseFloat(num2);

    alert (multiplicar);
}
function dividir(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    let  dividir= parseFloat(num1) / parseFloat(num2);

    alert (dividir);
}
function subtrair(){
    let num1 = document.getElementById("num1").value;
    let num2 = document.getElementById("num2").value;

    let  subtrair= parseFloat(num1) - parseFloat(num2);

    alert (subtrair);
}