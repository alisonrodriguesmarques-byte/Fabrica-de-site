// Perguntas
let lista = [
    ['Qual o nome do pai de Davi?', 'Jesse'],
    ['Qual o nome do pai de Jesus?', 'José']
];

document.getElementById('voltar').style.display = 'none';// esconder o botão de voltar

let indice = 0;

// Inicializa a primeira pergunta
document.getElementById('pergunta').innerText = lista[indice][0];

function botao() {
    let resposta = document.getElementById('resposta').value.trim();
    if (resposta === "") {
        alert("Por favor, preencha a Resposta");
        return;
    }

    // Verifica se está correta
    if (resposta.toLowerCase() === lista[indice][1].toLowerCase()) {
        document.getElementById("texto").innerText = `A resposta "${resposta}" é a certa 😁👍`;
    } else {
        document.getElementById("texto").innerText = `A resposta "${resposta}" está errada 😓`;
        return;
    }

    // Próxima pergunta
    indice++;
    if (indice < lista.length) {
        document.getElementById("pergunta").innerText = lista[indice][0];
        document.getElementById("resposta").value = "";
    } else {
        // Fim do quiz
        document.getElementById("pergunta").innerText = "✝️Fim do quiz!📖";
        document.getElementById("resposta").style.display = "none";
        document.getElementById("botao").style.display = "none";
        document.getElementById("voltar").style.display = ""; // Mostra botão voltar
    }
}
// Voltar
function voltar() {
    if (indice > 0) {
        indice = 0;
        document.getElementById('pergunta').innerText = lista[indice][0];
        document.getElementById('botao').style.display = "";
        document.getElementById("resposta").style.display = "";
        document.getElementById("resposta").value = "";
        document.getElementById("texto").innerText = 'Você está de volta à primeira pergunta.';
        document.getElementById('voltar').style.display = 'none'; // Esconder o botao
    }
}
